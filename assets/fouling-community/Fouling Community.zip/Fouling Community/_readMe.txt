This download contains all protocol materials for fouling community surveys, including protocol documents, printable field- and lab sheets, and data entry spreadsheets. The most up-to-date version of these materials are found at figshare using the DOIs associated with each protocol, listed below. 

Review "Fouling Community Survey Overview and Design" in the Fouling Community Protocol document to get started.

• Sampling Event
o https://doi.org/10.25573/serc.14555511
• Environmental Monitoring (temperature, salinity, turbidity)
o 
• Fouling Community Survey
o https://doi.org/10.25573/serc.14510649

Fully review these protocols necessary for the sampling excursion. Address any questions or concerns to marinegeo-protocols@si.edu before beginning protocols.

MarineGEO Fouling Community Monitoring Protocol. (2021) Janiak, Dean, Tennenbaum Marine Observatories Network, MarineGEO, Smithsonian Institution.
https://doi.org/10.25573/serc.14510649