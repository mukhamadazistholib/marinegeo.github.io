This download contains all protocol materials for oyster reef habitat surveys, including protocol documents, printable field- and lab sheets, and data entry spreadsheets. The most up-to-date version of these materials are found at figshare using the DOIs associated with each protocol, listed below. 

Review "Oyster Reef Habitat Survey Design" in the Oyster Reef Protocol document to get started.

• Sampling Event
o https://doi.org/10.25573/serc.14555511
• Environmental Monitoring (temperature, salinity, turbidity)
o 
• Oyster Reef Habitat Protocols
o https://doi.org/10.25573/serc.14714328

The overall design and replication adhere as closely as possible to other oyster reef monitoring
guidelines and in particular, much of this protocol was developed using the Oyster Habitat
Restoration Monitoring and Assessment Handbook (2014), complied by NOAA, The Nature
Conservancy, and others. Although the handbook was designed for restoration monitoring, it
adopts well to naturally occurring reefs. Our goal is to provide a standardized sampling design
that can be used in different regions and for restored or natural reefs, while still being comparative
in both space and time. 

Fully review these protocols necessary for the sampling excursion. Address any questions or concerns to marinegeo-protocols@si.edu before beginning protocols.

MarineGEO Oyster Reef Habitat Monitoring Protocol (2021). Janiak, Dean, Tennenbaum Marine Observatories Network, MarineGEO, Smithsonian Institution.
https://doi.org/10.25573/serc.14714328
