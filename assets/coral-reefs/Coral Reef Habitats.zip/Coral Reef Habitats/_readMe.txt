This download contains all protocol materials for coral reef habitat surveys, including protocol documents, printable field- and lab sheets, and data entry spreadsheets. The most up-to-date version of these materials are found at figshare using the DOIs associated with each protocol, listed below. 

Review "Salt Marsh Habitat Survey Overview and Design" in the Coral Reef Protocol document to get started.

• Sampling Event
o https://doi.org/10.25573/serc.14555511
• Environmental Monitoring (temperature, salinity, turbidity)
o 
• Visual census (fish and mobile invertebrate abundance, length, composition)
o https://doi.org/10.25573/serc.14717796
• Photoquadrats (benthic cover)
o https://doi.org/10.25573/serc.14717823
• Coral demographics (scleractinian community composition, signs of bleaching and disease)
• Predation (bait loss; ‘Squidpops’)
o https://doi.org/10.25573/serc.14717802
• Herbivory (bait loss; ‘Weedpops’ or ‘Ulva pops’)
o https://doi.org/10.25573/serc.14717808
• Substrate Rugosity

The methods in this protocol were adapted from Reef Life Survey (visual census, benthic photoquadrats), the IUCN Resilience Assessment of Coral Reefs rapid assessment protocol (coral demographics and conditions), and the CRTR Coral Disease Handbook (coral conditions assessment structure).  

Fully review these protocols necessary for the sampling excursion. Address any questions or concerns to marinegeo-protocols@si.edu before beginning protocols.

MarineGEO Coral Reef Habitat Monitoring. (2021) Harper, Leah, Tennenbaum Marine Observatories Network, MarineGEO, Smithsonian Institution.
https://doi.org/10.25573/serc.14714175