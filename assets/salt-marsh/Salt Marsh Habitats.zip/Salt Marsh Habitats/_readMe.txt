This download contains all protocol materials for salt marsh habitat surveys, including protocol documents, printable field- and lab sheets, and data entry spreadsheets. The most up-to-date version of these materials are found at figshare using the DOIs associated with each protocol, listed below. 

Review "Salt Marsh Survey Design" in the Salt Marsh Protocol document to get started.

• Sampling Event
o https://doi.org/10.25573/serc.14555511
• Environmental Monitoring (temperature, salinity, turbidity)
o 
• Beach seine or Visual census 
o Visual census: https://doi.org/10.25573/serc.14717796
o Beach seine: https://doi.org/10.25573/serc.14925105
• Predation (bait loss; ‘Squidpops’)
o https://doi.org/10.25573/serc.14717802
• Sediment organic matter
o https://doi.org/10.25573/serc.14925111
• Salt Marsh Protocols
o https://doi.org/10.25573/serc.14896194

Fully review these protocols necessary for the sampling excursion. Address any questions or concerns to marinegeo-protocols@si.edu before beginning protocols.

MarineGEO Salt Marsh Habitat Monitoring Protocol (2021). Jack Olson, Dennis Whigham, J. Patrick Megonigal, Matthew B. Ogburn, Tennenbaum Marine Observatories Network, MarineGEO, Smithsonian Institution. https://doi.org/10.25573/serc.14896194
