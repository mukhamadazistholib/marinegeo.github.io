#MarineGEO education materials
#Squidpop MarineGEO course module data activity. Using data and statistical analysis from Duffy et al. 2015
#The paper discusses multiple squidpop deployments and data is available for all. For this example analysis
#we will use only the data from Belize comparing predation rates among habitats. See Methods in paper for more
#details.

#Load required packages
require('lme4') #lme4 package for mixed effects models

#Clear working environment
rm(list = ls())

#Set working directory and load Squidpop data
setwd(~/...) #user defined

df <- read.csv("MarineGEO_SquidPop_Analysis_data.csv", header = T)

#review data object. Use 'head()' to preview columns and a few rows of data. You can see more or less rows 
#by head(.., # of rows), default is 5. 'names()' is also useful to call up exact names when defining modles.
head(df) 
names(df)

#check format of variables. We want our explanatory variables (Site, habitat type)
#to be factors for this analysis and our response variables (percent lost after 1 and 24hr) to be numeric
str(df)

#you can format variables using as.numeric() or as.factor()
df$Site <- as.factor(df$Site)

#To look at the distribution of the data, we can use hist()
hist(df$pct.lost.1hr)
hist(df$pct.lost.24hr)

#Data can be transformed to meet assumptions of normality. Compare transformed and untransformed fish abundance.
hist(df$fish.abundance)
hist(df$log.fish.abundance)


#The first question we will ask is whether or not predation rates differ among habitats. Following the methods
#in Duffy et al 2015, we will use a generalized linear mixed model. 

#We define the model for 1 hr.
modHab.1hr<- glmer(cbind(num.consumed.1hr,num.recover) ~ habitat.type + (1|site),
                family =binomial(link = "logit"),data = df)

#See the results
summary(modHab.1hr)

#Plot the data
boxplot(pct.lost.1hr ~ habitat.type, data = df)

#Now let's define the model for 24 hr.
modHab.24hr<- glmer(cbind(num.consumed.24hr,num.recover) ~ habitat.type + (1|site),
               family =binomial(link = "logit"),data = df)

#See the results
summary(modHab.24hr)

#Plot the data
boxplot(pct.lost.24hr ~ habitat.type, data = df)

#compare percent consumed to fish diversity. In this case the explanatory and response variables are numeric
#and continuous so we will use a linear regression. 
modfish <- lm(pct.lost.1hr ~ log.fish.richness, data = df, na.action = na.omit)
summary(modfish)

#plot the data
plot(pct.lost.1hr ~ log.fish.richness, data = df) 

#add trendline from our linear model
abline(modfish)
