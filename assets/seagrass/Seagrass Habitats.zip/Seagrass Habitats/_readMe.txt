This download contains all protocol materials for seagrass habitat surveys, including protocol documents, printable field- and lab sheets, and data entry spreadsheets. The most up-to-date version of these materials are found at figshare using the DOIs associated with each protocol, listed below. 

Review "Seagrass Habitat Survey Design" in the MarineGEO Seagrass Habitat Monitoring Protocol to get started.

• Sampling Event
o https://doi.org/10.25573/serc.14555511
• Environmental Monitoring (temperature, salinity, turbidity)
o 
• Beach seine or Visual census 
o Visual census: https://doi.org/10.25573/serc.14717796
o Beach seine: https://doi.org/10.25573/serc.14925105
• Predation (bait loss; ‘Squidpops’)
o https://doi.org/10.25573/serc.14717802
• Sediment organic matter
o https://doi.org/10.25573/serc.14925111
• Seagrass Protocols
o https://doi.org/10.25573/serc.14925114

The overall design and replication adheres as closely as possible to other seagrass monitoring programs, such as SeagrassNET and Seagrass Watch. Our goal is to provide a standardized sampling design and measurements of the key aspects of seagrass habitats that can be compared globally.

Fully review these protocols necessary for the sampling excursion. Address any questions or concerns to marinegeo-protocols@si.edu before beginning protocols.

Seagrass Habitat Monitoring Protocol (2021) Lefcheck, Jonathan, Tennenbaum Marine Observatories Network, MarineGEO, Smithsonian Institution. https://doi.org/10.25573/serc.14925114.v1